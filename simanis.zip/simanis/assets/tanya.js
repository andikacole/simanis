function hapus(){
	pesan = confirm("Yakin hapus data ini?");
	if (pesan == true) {
		return true;
	}else{
		return false;
	}
}

function logout(){
	pesan = confirm("Logout");
	if (pesan == true) {
		return true;
	}else{
		return false;
	}
}