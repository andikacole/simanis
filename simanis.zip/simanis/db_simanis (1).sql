-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 10, 2019 at 10:32 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_simanis`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(11) NOT NULL,
  `nama_admin` varchar(50) NOT NULL,
  `jk_admin` tinyint(1) NOT NULL,
  `telp_admin` varchar(15) NOT NULL,
  `username_admin` varchar(15) NOT NULL,
  `password_admin` varchar(255) NOT NULL,
  `foto_admin` varchar(150) NOT NULL,
  `status_admin` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id_admin`, `nama_admin`, `jk_admin`, `telp_admin`, `username_admin`, `password_admin`, `foto_admin`, `status_admin`) VALUES
(1, 'Master', 1, '081989745624', 'admin', '21232f297a57a5a743894a0e4a801fc3', '', ''),
(2, 'Indra', 1, '0808080808', 'indra', 'e24f6e3ce19ee0728ff1c443e4ff488d', '', ''),
(3, 'Andika', 0, '081246571421', 'andika', '7e51eea5fa101ed4dade9ad3a7a072bb', '1010201909570832.jpg', 'option1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_guru`
--

CREATE TABLE `tb_guru` (
  `id_guru` int(11) NOT NULL,
  `id_guru_mapel` int(11) NOT NULL,
  `id_wali_kls` int(11) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `nama_guru` varchar(150) NOT NULL,
  `jk_guru` tinyint(1) NOT NULL,
  `telp_guru` varchar(15) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `username_guru` varchar(15) NOT NULL,
  `password_guru` varchar(255) NOT NULL,
  `foto_guru` varchar(150) NOT NULL,
  `status_guru` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_guru`
--

INSERT INTO `tb_guru` (`id_guru`, `id_guru_mapel`, `id_wali_kls`, `nip`, `nama_guru`, `jk_guru`, `telp_guru`, `alamat`, `username_guru`, `password_guru`, `foto_guru`, `status_guru`) VALUES
(1, 0, 0, '1230890001', 'Andika Pranayoga', 1, '081246571421', 'Sanur', 'andika', '7e51eea5fa101ed4dade9ad3a7a072bb', '08102019132014Foto Andika.jpg', 'Aktif'),
(2, 0, 0, '1230900002', 'I Gede Indra Juliastrawan', 1, '081982928820', 'Renon', 'moyo', '7f3d09296993260d900daef15524963f', '08102019132102best-food-for-golden-retriever-puppies-header.jpg', 'Aktif'),
(3, 0, 0, '1240900004', 'Ni Made Putri', 0, '0182912891', 'Kintamani', 'putri', '4093fed663717c843bea100d17fb67c8', '08102019132312motor.jpg', 'Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `tb_guru_mapel`
--

CREATE TABLE `tb_guru_mapel` (
  `id_guru_mapel` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `semester` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_kelas`
--

CREATE TABLE `tb_kelas` (
  `id_kelas` int(11) NOT NULL,
  `id_wali_kls` int(11) NOT NULL,
  `nama_kelas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_kelas_siswa`
--

CREATE TABLE `tb_kelas_siswa` (
  `id_kelas_siswa` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `jml_siswa` int(11) NOT NULL,
  `tahun_ajaran` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_kkm`
--

CREATE TABLE `tb_kkm` (
  `id_kkm` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `nilai_kkm` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_mapel`
--

CREATE TABLE `tb_mapel` (
  `id_mapel` int(11) NOT NULL,
  `id_nilai_pengetahuan` int(11) NOT NULL,
  `id_nilai_keterampilan` int(11) NOT NULL,
  `id_guru_mapel` int(11) NOT NULL,
  `nama_mapel` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai_ekstrakulikuler`
--

CREATE TABLE `tb_nilai_ekstrakulikuler` (
  `id_ekstrakulikuler` int(11) NOT NULL,
  `id_nilai_siswa` int(11) NOT NULL,
  `nis` int(11) NOT NULL,
  `nama_ekstra1` varchar(50) NOT NULL,
  `nama_ekstra2` varchar(50) NOT NULL,
  `nilai_ekstra1` int(11) NOT NULL,
  `nilai_ekstra2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai_keterampilan`
--

CREATE TABLE `tb_nilai_keterampilan` (
  `id_nilai_keterampilan` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_nilai_siswa` int(11) NOT NULL,
  `nilai_praktek` int(11) NOT NULL,
  `nilai_projek` int(11) NOT NULL,
  `nilai_produk` int(11) NOT NULL,
  `nilai_portofolio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai_keterangan`
--

CREATE TABLE `tb_nilai_keterangan` (
  `id_keterangan` int(11) NOT NULL,
  `id_nilai_siswa` int(11) NOT NULL,
  `jml_sakit` varchar(10) NOT NULL,
  `jml_izin` varchar(10) NOT NULL,
  `jml_alpa` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai_pengetahuan`
--

CREATE TABLE `tb_nilai_pengetahuan` (
  `id_nilai_pengetahuan` int(11) NOT NULL,
  `id_mapel` int(11) NOT NULL,
  `id_nilai_siswa` int(11) NOT NULL,
  `test_tulis` int(11) NOT NULL,
  `penugasan` int(11) NOT NULL,
  `test_lisan` int(11) NOT NULL,
  `nilai_uas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai_sikap`
--

CREATE TABLE `tb_nilai_sikap` (
  `id_nilai_sikap` int(11) NOT NULL,
  `id_nilai_siswa` int(11) NOT NULL,
  `nilai_sikap` int(11) NOT NULL,
  `predikat` varchar(3) NOT NULL,
  `desk_spiritual` varchar(150) NOT NULL,
  `desk_sosial` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai_siswa`
--

CREATE TABLE `tb_nilai_siswa` (
  `id_nilai_siswa` int(11) NOT NULL,
  `id_nilai_keterampilan` int(11) NOT NULL,
  `id_guru_mapel` int(11) NOT NULL,
  `id_ekstrakulikuler` int(11) NOT NULL,
  `nis` int(11) NOT NULL,
  `id_nilai_sikap` int(11) NOT NULL,
  `id_nilai_keterangan` int(11) NOT NULL,
  `id_kkm` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `nis` int(11) NOT NULL,
  `nama_siswa` varchar(50) NOT NULL,
  `alamat_siswa` varchar(150) NOT NULL,
  `jk_siswa` tinyint(1) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `angkatan` varchar(5) NOT NULL,
  `username_siswa` varchar(15) NOT NULL,
  `password_siswa` varchar(255) NOT NULL,
  `foto_siswa` varchar(150) NOT NULL,
  `status_siswa` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_siswa`
--

INSERT INTO `tb_siswa` (`nis`, `nama_siswa`, `alamat_siswa`, `jk_siswa`, `id_kelas`, `angkatan`, `username_siswa`, `password_siswa`, `foto_siswa`, `status_siswa`) VALUES
(15101185, 'Tjokorda Ayu Baglug', 'Seset', 0, 0, '2015', 'ayu', '29c65f781a1068a41f735e1b092546de', '', ''),
(15101186, 'I Gusti Agung Mantan', 'Jl. Gang Gu Mantan', 0, 0, '2019', 'mantan', '70ec4d46b5b93141ad42d196071823fb', '1010201910293015.jpg', 'Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `tb_walikelas`
--

CREATE TABLE `tb_walikelas` (
  `id_wali` int(11) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `username_wali_kls` varchar(20) NOT NULL,
  `password_wali_kls` varchar(255) NOT NULL,
  `status_wali_kls` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `tb_guru`
--
ALTER TABLE `tb_guru`
  ADD PRIMARY KEY (`id_guru`),
  ADD KEY `id_guru_mapel` (`id_guru_mapel`,`id_wali_kls`);

--
-- Indexes for table `tb_guru_mapel`
--
ALTER TABLE `tb_guru_mapel`
  ADD PRIMARY KEY (`id_guru_mapel`),
  ADD KEY `id_kelas` (`id_kelas`,`id_guru`,`id_mapel`);

--
-- Indexes for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  ADD PRIMARY KEY (`id_kelas`),
  ADD KEY `id_wali_kls` (`id_wali_kls`);

--
-- Indexes for table `tb_kelas_siswa`
--
ALTER TABLE `tb_kelas_siswa`
  ADD PRIMARY KEY (`id_kelas_siswa`),
  ADD KEY `id_kelas` (`id_kelas`,`id_guru`);

--
-- Indexes for table `tb_kkm`
--
ALTER TABLE `tb_kkm`
  ADD PRIMARY KEY (`id_kkm`),
  ADD KEY `id_mapel` (`id_mapel`);

--
-- Indexes for table `tb_mapel`
--
ALTER TABLE `tb_mapel`
  ADD PRIMARY KEY (`id_mapel`),
  ADD KEY `id_nilai_pengetahuan` (`id_nilai_pengetahuan`,`id_nilai_keterampilan`,`id_guru_mapel`);

--
-- Indexes for table `tb_nilai_ekstrakulikuler`
--
ALTER TABLE `tb_nilai_ekstrakulikuler`
  ADD PRIMARY KEY (`id_ekstrakulikuler`),
  ADD KEY `id_nilai_siswa` (`id_nilai_siswa`,`nis`);

--
-- Indexes for table `tb_nilai_keterampilan`
--
ALTER TABLE `tb_nilai_keterampilan`
  ADD PRIMARY KEY (`id_nilai_keterampilan`),
  ADD KEY `id_mapel` (`id_mapel`,`id_nilai_siswa`);

--
-- Indexes for table `tb_nilai_keterangan`
--
ALTER TABLE `tb_nilai_keterangan`
  ADD PRIMARY KEY (`id_keterangan`),
  ADD KEY `id_nilai_siswa` (`id_nilai_siswa`);

--
-- Indexes for table `tb_nilai_pengetahuan`
--
ALTER TABLE `tb_nilai_pengetahuan`
  ADD PRIMARY KEY (`id_nilai_pengetahuan`),
  ADD KEY `id_mapel` (`id_mapel`,`id_nilai_siswa`);

--
-- Indexes for table `tb_nilai_sikap`
--
ALTER TABLE `tb_nilai_sikap`
  ADD PRIMARY KEY (`id_nilai_sikap`),
  ADD KEY `id_nilai_siswa` (`id_nilai_siswa`);

--
-- Indexes for table `tb_nilai_siswa`
--
ALTER TABLE `tb_nilai_siswa`
  ADD PRIMARY KEY (`id_nilai_siswa`),
  ADD KEY `id_nilai_keterampilan` (`id_nilai_keterampilan`,`id_guru_mapel`,`id_ekstrakulikuler`,`nis`,`id_nilai_sikap`,`id_nilai_keterangan`,`id_kelas`),
  ADD KEY `id_kkm` (`id_kkm`);

--
-- Indexes for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `tb_walikelas`
--
ALTER TABLE `tb_walikelas`
  ADD PRIMARY KEY (`id_wali`),
  ADD KEY `id_guru` (`id_guru`,`id_kelas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_guru`
--
ALTER TABLE `tb_guru`
  MODIFY `id_guru` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_guru_mapel`
--
ALTER TABLE `tb_guru_mapel`
  MODIFY `id_guru_mapel` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_kelas_siswa`
--
ALTER TABLE `tb_kelas_siswa`
  MODIFY `id_kelas_siswa` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_kkm`
--
ALTER TABLE `tb_kkm`
  MODIFY `id_kkm` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_mapel`
--
ALTER TABLE `tb_mapel`
  MODIFY `id_mapel` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_nilai_ekstrakulikuler`
--
ALTER TABLE `tb_nilai_ekstrakulikuler`
  MODIFY `id_ekstrakulikuler` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_nilai_keterampilan`
--
ALTER TABLE `tb_nilai_keterampilan`
  MODIFY `id_nilai_keterampilan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_nilai_keterangan`
--
ALTER TABLE `tb_nilai_keterangan`
  MODIFY `id_keterangan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_nilai_pengetahuan`
--
ALTER TABLE `tb_nilai_pengetahuan`
  MODIFY `id_nilai_pengetahuan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_nilai_sikap`
--
ALTER TABLE `tb_nilai_sikap`
  MODIFY `id_nilai_sikap` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_nilai_siswa`
--
ALTER TABLE `tb_nilai_siswa`
  MODIFY `id_nilai_siswa` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_walikelas`
--
ALTER TABLE `tb_walikelas`
  MODIFY `id_wali` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
