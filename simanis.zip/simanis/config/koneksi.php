<?php  
	$con = mysqli_connect("localhost","root","","db_simanis");
	if (!$con) {
		echo "<script>alert('Koneksi Database Gagal!');history.go(-1);</script>";
	}
?>