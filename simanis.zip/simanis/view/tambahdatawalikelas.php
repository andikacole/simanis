<?php  
    include '../control/auth.php';
	include 'layout/header.php';
	include 'layout/sidebar.php';
?>
	<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Tambah Data Wali Kelas</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Tambah Data Wali Kelas</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <form class="form-horizontal">
                            <div class="card-body">
                                    
                            <div class="col-md-8 offset-md-2">
                            <div class="form-group m-t-20">
                            <label>Nama Lengkap</label>
                            <input type="text" class="form-control" id="fname" placeholder="Nama Lengkap">
                            </div>
                                     
                            <div class="form-group m-t-20">
                            <label>Alamat</label>
                            <textarea class="form-control" placeholder="Alamat"></textarea>
                            </div>

                            <div class="form-group m-t-20"> 
                            <label>Jenis Kelamin</label><br>
                            <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                            <label class="form-check-label" for="inlineCheckbox1">Laki-Laki</label>
                            </div>
                            <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                            <label class="form-check-label" for="inlineCheckbox2">Perempuan</label>
                            </div>
                            </div>

                            <div class="form-group m-t-20">
                            <label>Telpon</label>
                            <input type="text" class="form-control" id="fname" placeholder="Telpon">
                            </div>

                            <div class="form-group m-t-20">
                            <label>Username</label>
                            <input type="text" class="form-control" id="fname" placeholder="Username">
                            </div>

                            <div class="form-group m-t-20">
                            <label>Password</label>
                            <input type="text" class="form-control" id="fname" placeholder="Password">
                            </div>

                            <form>
                            <div class="form-group m-t-20">
                            <label for="exampleFormControlFile1">Foto</label>
                            <input type="file" class="form-control-file" id="exampleFormControlFile1">
                            </div>
                            </form>

                            <div class="form-group m-t-20"> 
                            <label>Status</label><br>
                            <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                            <label class="form-check-label" for="inlineCheckbox1">Aktif</label>
                            </div>
                            <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                            <label class="form-check-label" for="inlineCheckbox2">Tidak Aktif</label>
                            </div>
                            </div>

                                <div class="border-top">
                                    <div class="card-body">
                                        <button type="button" class="btn btn-primary">Simpan</button> <button type="button" class="btn btn-primary">Kembali</button>
                                    </div>
                                    
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
<?php  
	include 'layout/footer.php';
?>