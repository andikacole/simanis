<?php  
    include '../control/auth.php';
	include 'layout/header.php';
	include 'layout/sidebar.php';
?>
<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Tambah Data Admin</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Tambah Data Admin</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <form action="../control/addadmin.php" class="form-horizontal" method="POST" enctype="multipart/form-data">
                                <div class="card-body">
                                    
                                <div class="col-md-8 offset-md-2">
                                <div class="form-group m-t-20">
                                    <label>Nama Lengkap</label>
                                    <input type="text" class="form-control" id="fname" placeholder="Nama Lengkap" name="nama" required="required">
                                </div>

                                <div class="form-group m-t-20">
                                    <label>Telpon</label>
                                    <input type="text" class="form-control" id="fname" placeholder="Telpon" name="telp" required="required">
                                </div>

                                <div class="form-group m-t-20"> 
                                <label>Jenis Kelamin</label><br>
                                <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="inlineCheckbox1" value="1" name="jk" required>
                                <label class="form-check-label" for="inlineCheckbox1">Laki-Laki</label>
                                </div>
                                <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="inlineCheckbox2" value="0" name="jk" required>
                                <label class="form-check-label" for="inlineCheckbox2">Perempuan</label>
                                </div>
                                </div>

                                <div class="form-group m-t-20">
                                    <label>Username</label>
                                    <input type="text" class="form-control" id="fname" placeholder="Username" name="user" required="required">
                                </div>

                                <div class="form-group m-t-20">
                                    <label>Password</label>
                                    <input type="password" class="form-control" id="fname" placeholder="Password" name="pass" required="required">
                                </div>
								
								<form>
  								<div class="form-group m-t-20">
    								<label for="exampleFormControlFile1">Foto</label>
    								<input type="file" class="form-control-file" id="exampleFormControlFile1" name="foto" required="required">
  								</div>
								</form>

							<div class="form-group m-t-20">	
							<label>Status</label><br>
							<div class="form-check form-check-inline">
  							<input class="form-check-input" type="radio" id="inlineCheckbox3" value="option1" name="status" required="required">
  							<label class="form-check-label" for="inlineCheckbox3">Aktif</label>
							</div>
							<div class="form-check form-check-inline">
  							<input class="form-check-input" type="radio" id="inlineCheckbox4" value="option2" name="status" required="required">
  							<label class="form-check-label" for="inlineCheckbox4">Tidak Aktif</label>
							</div>
							</div>

                                                                
                                <div class="border-top">
                                    <input type="submit" class="btn btn-primary" name="button" value="Simpan">
                                    <a href="dataadmin.php" class="btn btn-secondary">Kembali</a>
                                </div>
                            </div>
								</div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
<?php  
	include 'layout/footer.php';
?>