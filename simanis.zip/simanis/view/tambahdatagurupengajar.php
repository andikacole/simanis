<?php  
    include '../control/auth.php';
	include 'layout/header.php';
	include 'layout/sidebar.php';
?>
<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Tambah Data Guru Pengajar</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Tambah Data Guru Pengajar</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <form class="form-horizontal">
                                <div class="card-body">
                                    
                                <div class="col-md-8 offset-md-2">
                                <div class="form-group m-t-20">
                                <label>Nama Guru</label>
                                    <select class="form-control" id="exampleFormControlSelect1">
                                    <option>Pilih Nama Guru</option>
                                    <option>Eko</option>
                                    <option>Gunggus</option>
                                    <option>Angga</option>
                                    <option>Lucas</option>
                                    <option>Modric</option>
                                    </select>
                                    </div>

                                    
                                <div class="form-group m-t-20">
                                <label>Mata Pelajaran</label>
                                    <select class="form-control" id="exampleFormControlSelect1">
                                    <option>Pilih Mata Pelajaran</option>
                                    <option>Matematika</option>
                                    <option>Fotografi</option>
                                    <option>Bhs Jepang</option>
                                    <option>Film Porno</option>
                                    <option>Clasic Porn</option>
                                    </select>
                                    </div>

                                <div class="form-group m-t-20">
                                <label>Kelas</label>
                                    <select class="form-control" id="exampleFormControlSelect1">
                                    <option>Pilih Kelas</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    </select>
                                    </div>

                                <div class="form-group m-t-20">
                                <label>Semester</label>
                                    <select class="form-control" id="exampleFormControlSelect1">
                                    <option>Pilih Semester</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    </select>
                                    </div>

                                <div class="form-group m-t-20">
                                <label>Tahun Ajaran</label>
                                    <select class="form-control" id="exampleFormControlSelect1">
                                    <option>Pilih Tahun Ajaran</option>
                                    <option>2001</option>
                                    <option>2002</option>
                                    <option>2003</option>
                                    <option>2004</option>
                                    <option>2005</option>
                                    </select>
                                    </div>
                                    
                                <div class="border-top">
                                    <div class="card-body">
                                        <button type="button" class="btn btn-primary">Simpan</button> <button type="button" class="btn btn-primary">Kembali</button>
                                    </div>

                                </div>


                                    </div>

                                    </div>
                                    

                            </form>
                        </div>
                    </div>
                </div>
            </div>
<?php  
	include 'layout/footer.php';
?>