<?php  
    include '../control/auth.php';
    include '../config/koneksi.php';
	include 'layout/header.php';
	include 'layout/sidebar.php';
?>
<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Data Guru</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Data Guru</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="card">
                <div class="card-body">
                    <a type="button" href="tambahdataguru.php" class="btn btn-primary">Tambah Data Guru</a>
                    <hr>
                    <div class="table-responsive">
                        <table class="table table-striped" id="myTable">
                            <thead>
                                <tr>
                                    <th><strong>#</strong></th>
                                    <th><strong>NIP</strong></th>
                                    <th><strong>Nama</strong></th>
                                    <th><strong>Jenis Kelamin</strong></th>
                                    <th><strong>Kontak</strong></th>
                                    <th><strong>Alamat</strong></th>
                                    <th><strong>Status</strong></th>
                                    <th><strong>Aksi</strong></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php  
                                    $no = 0;
                                    $query = mysqli_query($con, "SELECT * FROM tb_guru");
                                    while ($data = mysqli_fetch_array($query)) {
                                        $no ++;
                                        $id = $data['id_guru'];
                                        if ($data['jk_guru'] == 1) {
                                            $jk = "Laki - Laki";
                                        }else{
                                            $jk = "Perempuan";
                                        }
                                        echo "
                                            <tr>
                                                <td>".$no."</td>
                                                <td>".$data['nip']."</td>
                                                <td>".$data['nama_guru']."</td>
                                                <td>".$jk."</td>
                                                <td>".$data['telp_guru']."</td>
                                                <td>".$data['alamat']."</td>
                                                <td>".$data['status_guru']."</td>
                                                <td>
                                                    <abbr title='Detail'><a type='button' class='btn btn-success' href='../control/detaildataguru.php?id_guru=$id'><i class='fas fa-eye'></i></a></abbr> 
                                                    | <abbr title='Ubah'><a type='button' class='btn btn-info' href='../control/editdataguru.php?id_guru=$id'><i class='fas fa-pencil-alt'></i></a></abbr> 
                                                    | <abbr title='Hapus'><a type='button' class='btn btn-danger' href='../control/hapusdataguru.php?id_guru=$id' onclick='return hapus()'><i class='fas fa-trash'></i></a></abbr>
                                                </td>
                                            </tr>
                                        ";
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
<?php  
	include 'layout/footer.php';
?>