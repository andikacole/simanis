<?php  
    include '../control/auth.php';
	include 'layout/header.php';
	include 'layout/sidebar.php';
?>
<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Data Kelas</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Data Kelas</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="card-body">
                  <a type="button" href="tambahdatakelas.php" class="btn btn-primary">Tambah Data Kelas</a>
            </div>
<?php  
	include 'layout/footer.php';
?>