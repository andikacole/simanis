<?php  
    include '../control/auth.php';
	include 'layout/header.php';
	include 'layout/sidebar.php';
?>
	<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Tambah Data Kelas</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Tambah Data Kelas</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <form class="form-horizontal">
                                <div class="card-body">
                                    
                                <div class="col-md-8 offset-md-2">
                                <div class="form-group m-t-20">
                                <label>Kelas</label>
                                <input type="text" class="form-control" id="fname" placeholder="Kelas">
                                </div>

                                <div class="border-top">
                                    <div class="card-body">
                                        <center><button type="button" class="btn btn-primary">Simpan</button> <button type="button" class="btn btn-primary">Kembali</button></center>
                                    </div>
                                    
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
<?php  
	include 'layout/footer.php';
?>