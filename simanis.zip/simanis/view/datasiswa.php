<?php  
    include '../control/auth.php';
    include '../config/koneksi.php';
	include 'layout/header.php';
	include 'layout/sidebar.php';
?>
<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Data Siswa</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Data Siswa</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="card">
                <div class="card-body">
                    <a type="button" href="tambahdatasiswa.php" class="btn btn-primary">Tambah Data Siswa</a>
                    <hr>
                    <div class="table-responsive">
                        <table class="table table-striped" id="myTable">
                            <thead>
                                <tr>
                                    <th><strong>#</strong></th>
                                    <th><strong>NIS</strong></th>
                                    <th><strong>Nama</strong></th>
                                    <th><strong>Jenis Kelamin</strong></th>
                                    <th><strong>Angkatan</strong></th>
                                    <th><strong>Alamat</strong></th>
                                    <th><strong>Aksi</strong></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php  
                                    $no = 0;
                                    $query = mysqli_query($con, "SELECT * FROM tb_siswa");
                                    while ($data = mysqli_fetch_array($query)) {
                                        $no ++;
                                        $id = $data['nis'];
                                        if ($data['jk_siswa'] == 1) {
                                            $jk = "Laki - Laki";
                                        }else{
                                            $jk = "Perempuan";
                                        }
                                        echo "
                                            <tr>
                                                <td>".$no."</td>
                                                <td>".$data['nis']."</td>
                                                <td>".$data['nama_siswa']."</td>
                                                <td>".$jk."</td>
                                                <td>".$data['angkatan']."</td>
                                                <td>".$data['alamat_siswa']."</td>
                                                <td>
                                                    <abbr title='Detail'><a type='button' class='btn btn-success' href='../control/detaildatasiswa.php?nis=$id'><i class='fas fa-eye'></i></a></abbr> 
                                                    | <abbr title='Ubah'><a type='button' class='btn btn-info' href='../control/editdatasiswa.php?nis=$id'><i class='fas fa-pencil-alt'></i></a></abbr> 
                                                    | <abbr title='Hapus'><a type='button' class='btn btn-danger' href='../control/hapusdatasiswa.php?nis=$id' onclick='return hapus()'><i class='fas fa-trash'></i></a></abbr>
                                                </td>
                                            </tr>
                                        ";
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
<?php  
	include 'layout/footer.php';
?>