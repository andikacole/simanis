<?php  
    include '../control/auth.php';
    include '../config/koneksi.php';
	include 'layout/header.php';
	include 'layout/sidebar.php';
?>
<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Data Admin</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Data Admin</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
                  
        <div class="card">
            <div class="card-body">
                <a type="button" href="tambahdataadmin.php" class="btn btn-primary">Tambah Data Admin</a>
                <hr>
                <div class="table-responsive">
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th><strong>#</strong></th>
                                <th><strong>Username</strong></th>
                                <th><strong>Nama</strong></th>
                                <th><strong>Jenis Kelamin</strong></th>
                                <th><strong>Kontak</strong></th>
                                <th><strong>Aksi</strong></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php  
                                $no = 0;
                                $query = mysqli_query($con, "SELECT * FROM tb_admin");
                                while ($data = mysqli_fetch_array($query)) {
                                    $no ++;
                                    $id = $data['id_admin'];
                                    if ($data['jk_admin'] == 1) {
                                        $jk = "Laki - Laki";
                                    }else{
                                        $jk = "Perempuan";
                                    }
                                    echo "
                                        <tr>
                                            <td>".$no."</td>
                                            <td>".$data['username_admin']."</td>
                                            <td>".$data['nama_admin']."</td>
                                            <td>".$jk."</td>
                                            <td>".$data['telp_admin']."</td>
                                            <td>
                                                <abbr title='Ubah'><a type='button' class='btn btn-info' href='../control/editdataadmin.php?id_admin=$id'><i class='fas fa-pencil-alt'></i></a></abbr> 
                                                | <abbr title='Hapus'><a type='button' class='btn btn-danger' href='../control/hapusdataadmin.php?id_admin=$id' onclick='return hapus()'><i class='fas fa-trash'></i></a></abbr>
                                            </td>
                                        </tr>
                                    ";
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php  
	include 'layout/footer.php';
?>