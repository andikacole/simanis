<?php  
    include '../control/auth.php';
	include 'layout/header.php';
	include 'layout/sidebar.php';
?>
<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Data Nilai Siswa</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Data Nilai Siswa</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            
            <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <form class="form-horizontal">
                                <div class="card-body">
                                    
                                <div class="col-md-8 offset-md-2">

                                <div class="border-top" align="right">
                                    <div class="card-body">
                                        <a type="button" href="datanilaisiswa.php" class="btn btn-primary">Kembali</a> 
                                    </div>
                                    </div>

                                    </div>
                                    

                            </form>
                        </div>
                    </div>
                </div>
            </div>
<?php  
	include 'layout/footer.php';
?>