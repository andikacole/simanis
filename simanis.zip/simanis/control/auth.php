<?php  
	session_start();
	if ($_SESSION['status']!="login") {
		echo "<script>alert('Kamu Belum Login!');window.location='../../index.php'</script>";
	}
?>