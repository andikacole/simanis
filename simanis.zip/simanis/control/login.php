<?php
	include '../config/koneksi.php';
	if (isset($_POST['button'])) {
		$user = $_POST['user'];
		$pass = md5($_POST['pass']);

		$admin = mysqli_query($con, "SELECT * FROM tb_admin WHERE username_admin = '$user' AND password_admin = '$pass'");
		$guru = mysqli_query($con, "SELECT * FROM tb_guru WHERE username_guru = '$user' AND password_guru = '$pass'");
		$wali = mysqli_query($con, "SELECT * FROM tb_walikelas WHERE username_wali_kls = '$user' AND password_wali_kls = '$pass'");
		$siswa = mysqli_query($con, "SELECT * FROM tb_siswa WHERE username_siswa = '$user' AND password_siswa = '$pass'");

		$cekadmin = mysqli_fetch_array($admin);
		$cekguru = mysqli_fetch_array($guru);
		$cekwali = mysqli_fetch_array($wali);
		$ceksiswa = mysqli_fetch_array($siswa);

		if (($cekadmin > 0) OR ($cekguru > 0) OR ($cekwali > 0) OR ($ceksiswa > 0) ) {
			if (

				(($user == $cekadmin['username_admin']) AND ($pass == $cekadmin['password_admin'])) OR
				(($user == $cekguru['username_guru']) AND ($pass == $cekguru['password_guru'])) OR
				(($user == $cekwali['username_wali_kls']) AND ($pass == $cekwali['password_wali_kls'])) OR
				(($user == $ceksiswa['username_siswa']) AND ($pass == $ceksiswa['password_siswa']))
				
				){
				session_start();
				$_SESSION['status']="login";
				$_SESSION['username']=$user;
				header('Location:../view/dashboard.php');
			}else{
				echo "<script>alert('Username atau Password salah!');history.go(-1);</script>";
			}
		}else{
			echo "<script>alert('Username Tidak Terdaftar!');history.go(-1);</script>";
		}
	}
?>
