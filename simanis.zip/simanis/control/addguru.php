<?php  
	include '../config/koneksi.php';
	if (isset($_POST['button'])) {
		$nip = $_POST['nip'];
		$nama = $_POST['nama'];
		$alamat = $_POST['alamat'];
		$jk = $_POST['jk'];
		$telp = $_POST['telp'];
		$user = $_POST['user'];
		$pass = md5($_POST['pass']);
		$status = $_POST['status'];

		$foto = $_FILES['foto']['name'];
		$nama_tmp = $_FILES['foto']['tmp_name'];

		$fotoBaru = date('dmYHis').$foto;

		$folder = "../upload/".$fotoBaru;

		if (move_uploaded_file($nama_tmp, $folder)) {
			$query = mysqli_query($con, "INSERT INTO tb_guru (nip, nama_guru, alamat, jk_guru, telp_guru, username_guru, password_guru, status_guru, foto_guru) VALUES ('$nip','$nama','$alamat','$jk','$telp','$user','$pass','$status','$fotoBaru')");
			if ($query) {
				echo "<script>alert('Data berhasil disimpan');window.location='../view/dataguru.php'</script>";
			}else{
				echo "<script>alert('Gagal menyimpan data');history.go(-1);</script>";
			}
		}else{
			echo "<script>alert('Gagal menyimpan foto');history.go(-1);</script>";
		}
	}
?>