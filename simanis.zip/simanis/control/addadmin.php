<?php
	include '../config/koneksi.php';
	if (isset($_POST['button'])) {
		$nama = $_POST['nama'];
		$jk = $_POST['jk'];
		$telp = $_POST['telp'];
		$user = $_POST['user'];
		$pass = md5($_POST['pass']);
		$status = $_POST['status'];

		$foto = $_FILES['foto']['name'];
		$nama_tmp = $_FILES['foto']['tmp_name'];

		$fotoBaru = date('dmYHis').$foto;

		$folder = "../upload/".$fotoBaru;

		if (move_uploaded_file($nama_tmp, $folder)) {
			$query = mysqli_query($con, "INSERT INTO tb_admin (nama_admin, jk_admin, telp_admin, username_admin, password_admin, status_admin, foto_admin) VALUES ('$nama','$jk','$telp','$user','$pass','$status','$fotoBaru')");
			if ($query) {
				echo "<script>alert('Data berhasil disimpan');window.location='../view/dataadmin.php'</script>";
			}else{
				echo "<script>alert('Gagal menyimpan data');history.go(-1);</script>";
			}
		}else{
			echo "<script>alert('Gagal menyimpan foto');history.go(-1);</script>";
		}
	}
?>
